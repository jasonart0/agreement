<div class="step active">
    <div class="general-provisions">
        <div class="contract-title text-start">GENERAL PROVISIONS</div>
        <ul>
            <li>
                This Agreement will inure to the benefit of and be binding upon the respective heirs, executors,
                administrators, successors, and assigns, as the case may be, of the Employer and the Employee.
            </li>
            <li>
                This Agreement may be executed in counterparts. Facsimile signatures are binding and are considered to
                be original signatures.
            </li>
            <li>
                If, at the time of execution of this Agreement, there is a pre-existing employment agreement still in
                effect between the parties to this Agreement, then in consideration of and as a condition of the parties
                entering into this Agreement and other valuable consideration, the receipt and sufficiency of which
                consideration is acknowledged, this Agreement will supersede any and all pre-existing employment
                agreements between the Employer and the Employee. Any duties, obligations, and liabilities still in
                effect from any pre-existing employment agreement are void and no longer enforceable after execution of
                this Agreement.
            </li>
            <li>
                This Agreement constitutes the entire agreement between the parties and there are no further items or
                provisions, either oral or written. The parties to this Agreement stipulate that neither of them has
                made any representations with respect to the subject matter of this Agreement except such
                representations as are specifically set forth in this Agreement.
            </li>
        </ul>
    </div>

    <div class="witness-section">
        <p>
            <strong>IN WITNESS WHEREOF,</strong> The parties have duly affixed their signatures under hand and seal on
            this
        <div class="d-flex gap-2">
            <?php $widtness_day = (isset($data)) ? $data->widtness_day : old("widtness_day"); ?>
            <span><input type="number" min="1" max="31" class="input-field w-90" name="widtness_day" value="<?php echo e($widtness_day); ?>"
                    id="witness-day" placeholder="Day" /></span>
            <span>day of</span>
            <?php $widtness_month = (isset($data)) ? $data->widtness_month : old("widtness_month"); ?>
            <span><input type="number" min="1" max="12" class="input-field w-80" name="widtness_month" value="<?php echo e($widtness_month); ?>"
                    id="witness-month" placeholder="Month" />,</span>
                    <?php $widtness_year = (isset($data)) ? $data->widtness_year : old("widtness_year"); ?>
            <span> <input type="number" min="1900" max="2100" class="input-field w-90" name="widtness_year" value="<?php echo e($widtness_year); ?>"
                    id="witness-year" placeholder="Year" />.</span>
        </div>
        </p>

        <div class="signatures flex-row">
            <div class="w-50">
                <div class="signature-block">
                    <?php $fitness_field_one = (isset($data)) ? $data->fitness_field_one : old("fitness_field_one"); ?>
                    <input type="text" class="input-field w-90" name="fitness_field_one" value="<?php echo e($fitness_field_one); ?>"/>
                    <p>Witness</p>
                </div>

                <div class="signature-block">
                    <?php $witness_name_1 = (isset($data)) ? $data->witness_name_1 : old("witness_name_1"); ?>
                    <input type="text" class="input-field w-90" name="witness_name_1" value="<?php echo e($witness_name_1); ?>" />
                    <p>Witness</p>
                </div>
            </div>
            <div class="w-50">
                <div class="signature-block">
                    <p><strong>HybridX Inc.</strong></p>
                    <?php $witness_person = (isset($data)) ? $data->witness_person : old("witness_person"); ?>
                    <p class="flex-row">Per:<input type="text" class="input-field w-90" name="witness_person" value="<?php echo e($witness_person); ?>" /></p>
                    <?php $witness_person_name =  (isset($data)) ? $data->witness_person_name : old("witness_person_name"); ?>
                    <p class="flex-row">Name:<input type="text" class="input-field w-90" name="witness_person_name" value="<?php echo e($witness_person_name); ?>" /></p>
                </div>
                <div class="signature-block">
                    <?php $witness_field2 = (isset($data)) ? $data->witness_field2 : old("witness_field2"); ?>
                    <p><input type="text" class="input-field w-90" name="witness_field2" value="<?php echo e($witness_field2); ?>"/></p>
                </div>
            </div>
        </div>
    </div>


    <div class="signature-section">
        <?php if(isset($data->signature_step12)): ?>
            <img src="<?php echo e($data->signature_step12); ?>" style="width: 150px;">
        <?php else: ?>
            <canvas id="signaturePad12" class="signature-pad"></canvas>
            <div class="flex-row mt-3">
                <label for="signaturePad12">Signature</label>
                <a href="javascript:;" class="clearsignature" onclick="clearSignature(12)">Clear Signature</a>
                <?php $signature_step12 = (isset($data)) ? $data->signature_step12 : old("signature_step12"); ?>
                <input type="hidden" id="signature_step12" name="signature_step12" value="<?php echo e($signature_step12); ?>"
                    value="<?php echo e(old('signature_step12')); ?>">

                <?php $__errorArgs = ['signature_step12'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div style="color: red;"><?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        <?php endif; ?>
    </div>
    <div class="form-footer">
        <input type="submit" value="Submit">
    </div>
    
</div>
<?php /**PATH D:\wamp64\www\projects\agreement\resources\views/page12.blade.php ENDPATH**/ ?>